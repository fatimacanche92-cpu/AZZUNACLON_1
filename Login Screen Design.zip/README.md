
  # Login Screen Design

  This is a code bundle for Login Screen Design. The original project is available at https://www.figma.com/design/VERRvY5ALBCa1sBPowiwq4/Login-Screen-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  